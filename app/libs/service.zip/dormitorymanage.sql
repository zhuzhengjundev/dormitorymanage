/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50722
Source Host           : localhost:3306
Source Database       : dormitorymanage

Target Server Type    : MYSQL
Target Server Version : 50722
File Encoding         : 65001

Date: 2020-02-09 09:36:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `dormitory`
-- ----------------------------
DROP TABLE IF EXISTS `dormitory`;
CREATE TABLE `dormitory` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '宿舍id号',
  `tung` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '楼号',
  `room` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '房间号',
  `gender` varchar(20) NOT NULL COMMENT '宿舍所属性别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dormitory
-- ----------------------------
INSERT INTO `dormitory` VALUES ('1', '1', '1-101', '男');
INSERT INTO `dormitory` VALUES ('2', '1', '1-102', '男');
INSERT INTO `dormitory` VALUES ('3', '1', '1-103', '男');
INSERT INTO `dormitory` VALUES ('4', '1', '1-104', '男');
INSERT INTO `dormitory` VALUES ('5', '1', '1-105', '男');
INSERT INTO `dormitory` VALUES ('6', '1', '1-201', '男');
INSERT INTO `dormitory` VALUES ('7', '1', '1-202', '男');
INSERT INTO `dormitory` VALUES ('8', '1', '1-203', '男');
INSERT INTO `dormitory` VALUES ('9', '1', '1-204', '男');
INSERT INTO `dormitory` VALUES ('10', '1', '1-205', '男');
INSERT INTO `dormitory` VALUES ('11', '1', '1-301', '男');
INSERT INTO `dormitory` VALUES ('12', '1', '1-302', '男');
INSERT INTO `dormitory` VALUES ('13', '1', '1-303', '男');
INSERT INTO `dormitory` VALUES ('14', '1', '1-304', '男');
INSERT INTO `dormitory` VALUES ('15', '1', '1-305', '男');
INSERT INTO `dormitory` VALUES ('16', '2', '2-101', '男');
INSERT INTO `dormitory` VALUES ('17', '2', '2-102', '男');
INSERT INTO `dormitory` VALUES ('18', '2', '2-103', '男');
INSERT INTO `dormitory` VALUES ('19', '2', '2-104', '男');
INSERT INTO `dormitory` VALUES ('20', '2', '2-105', '男');
INSERT INTO `dormitory` VALUES ('21', '2', '2-201', '男');
INSERT INTO `dormitory` VALUES ('22', '2', '2-202', '男');
INSERT INTO `dormitory` VALUES ('23', '2', '2-203', '男');
INSERT INTO `dormitory` VALUES ('24', '2', '2-204', '男');
INSERT INTO `dormitory` VALUES ('25', '2', '2-205', '男');
INSERT INTO `dormitory` VALUES ('26', '2', '2-301', '男');
INSERT INTO `dormitory` VALUES ('27', '2', '2-302', '男');
INSERT INTO `dormitory` VALUES ('28', '2', '2-303', '男');
INSERT INTO `dormitory` VALUES ('29', '2', '2-304', '男');
INSERT INTO `dormitory` VALUES ('30', '2', '2-305', '男');
INSERT INTO `dormitory` VALUES ('31', '3', '3-101', '女');
INSERT INTO `dormitory` VALUES ('32', '3', '3-102', '女');
INSERT INTO `dormitory` VALUES ('33', '3', '3-103', '女');
INSERT INTO `dormitory` VALUES ('34', '3', '3-104', '女');
INSERT INTO `dormitory` VALUES ('35', '3', '3-105', '女');
INSERT INTO `dormitory` VALUES ('36', '3', '3-201', '女');
INSERT INTO `dormitory` VALUES ('37', '3', '3-202', '女');
INSERT INTO `dormitory` VALUES ('38', '3', '3-203', '女');
INSERT INTO `dormitory` VALUES ('39', '3', '3-204', '女');
INSERT INTO `dormitory` VALUES ('40', '3', '3-205', '女');
INSERT INTO `dormitory` VALUES ('41', '3', '3-301', '女');
INSERT INTO `dormitory` VALUES ('42', '3', '3-302', '女');
INSERT INTO `dormitory` VALUES ('43', '3', '3-303', '女');
INSERT INTO `dormitory` VALUES ('44', '3', '3-304', '女');
INSERT INTO `dormitory` VALUES ('45', '3', '3-305', '女');

-- ----------------------------
-- Table structure for `dormitorymanag`
-- ----------------------------
DROP TABLE IF EXISTS `dormitorymanag`;
CREATE TABLE `dormitorymanag` (
  `id` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿管id号',
  `pwd` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿管密码',
  `name` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿管姓名',
  `dormitory_num` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '管理的楼栋编号',
  `manage_xb` varchar(20) NOT NULL COMMENT '管理的性别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dormitorymanag
-- ----------------------------
INSERT INTO `dormitorymanag` VALUES ('admin1', '123456', '李大力', '1', '男');
INSERT INTO `dormitorymanag` VALUES ('admin2', '123456', '王大宝', '2', '男');
INSERT INTO `dormitorymanag` VALUES ('admin3', '123456', '戚美琳', '3', '女');

-- ----------------------------
-- Table structure for `hygiene`
-- ----------------------------
DROP TABLE IF EXISTS `hygiene`;
CREATE TABLE `hygiene` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '卫生检查id号',
  `dormitoryid` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿舍id号',
  `grade` varchar(20) NOT NULL COMMENT '卫生等级',
  `remark` varchar(200) DEFAULT NULL COMMENT '评语',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '检查时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hygiene
-- ----------------------------
INSERT INTO `hygiene` VALUES ('1', '1-101', '差', '3131', '2020年02月07日 06:27:21');
INSERT INTO `hygiene` VALUES ('2', '1-102', '优', '2124', '2020年02月07日 06:44:35');

-- ----------------------------
-- Table structure for `lostarticle`
-- ----------------------------
DROP TABLE IF EXISTS `lostarticle`;
CREATE TABLE `lostarticle` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '失物招领id号',
  `title` varchar(50) DEFAULT NULL COMMENT '标题',
  `content` varchar(200) DEFAULT NULL COMMENT '内容',
  `img` varchar(1000) DEFAULT NULL COMMENT '失物图片',
  `phonenumber` varchar(20) CHARACTER SET gbk DEFAULT NULL COMMENT '联系方式',
  `stat` varchar(20) NOT NULL COMMENT '状态',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of lostarticle
-- ----------------------------
INSERT INTO `lostarticle` VALUES ('2', '214', '1414', 'http://172.20.10.2:8181/dormitoryManage/upload/shiwuImg/1581075716521_timg-1.jpg\n', '1414', '认领', '2020年02月07日 11:41:56');
INSERT INTO `lostarticle` VALUES ('3', '24', '515', 'http://172.20.10.2:8181/dormitoryManage/upload/shiwuImg/1581077147443_timg.jpg\n', '51', '丢失', '2020年02月07日 12:05:47');
INSERT INTO `lostarticle` VALUES ('4', '52', '525', 'http://172.20.10.2:8181/dormitoryManage/upload/shiwuImg/1581077275049_timg.jpg\n', '2552', '认领', '2020年02月07日 12:07:54');

-- ----------------------------
-- Table structure for `notice`
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '公告信息id号',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `content` varchar(200) NOT NULL COMMENT '内容',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('5', '31', '414', '2020年02月07日 07:27:23');

-- ----------------------------
-- Table structure for `repair`
-- ----------------------------
DROP TABLE IF EXISTS `repair`;
CREATE TABLE `repair` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '宿舍维修id号',
  `dormitoryid` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿舍id号',
  `name` varchar(20) NOT NULL COMMENT '维修人员姓名',
  `remark` varchar(200) NOT NULL COMMENT '维修物品',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of repair
-- ----------------------------
INSERT INTO `repair` VALUES ('1', '1', '1', '1', '2020年02月07日 02:53:51');
INSERT INTO `repair` VALUES ('2', '1-101', '121322', '1241', '2020年02月07日 04:23:32');
INSERT INTO `repair` VALUES ('3', '1-101', '12414124', '1414', '2020年02月07日 04:23:38');
INSERT INTO `repair` VALUES ('4', '1-102', '121', '122', '2020年02月07日 05:04:49');
INSERT INTO `repair` VALUES ('5', '1-101', '21', '12', '2020年02月07日 06:26:47');

-- ----------------------------
-- Table structure for `student`
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '学生账号',
  `pwd` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '学生密码',
  `name` varchar(20) NOT NULL COMMENT '学生姓名',
  `gender` varchar(20) NOT NULL COMMENT '学生性别',
  `img` varchar(100) CHARACTER SET gbk DEFAULT NULL COMMENT '学生照片',
  `age` varchar(20) CHARACTER SET gbk DEFAULT NULL COMMENT '学生年龄',
  `nativeplace` varchar(50) DEFAULT NULL COMMENT '学生籍贯',
  `major` varchar(20) DEFAULT NULL COMMENT '学生所在专业',
  `hobby` varchar(100) DEFAULT NULL COMMENT '学生爱好',
  `dormitoryid` varchar(20) CHARACTER SET gbk DEFAULT NULL COMMENT '学生所在宿舍id号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('111111', '1', '小军', '男', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '242', '41', '4241', '414', '1-201');
INSERT INTO `student` VALUES ('11114141', '14124', '1241', '男', '', '', '', '', '', '');
INSERT INTO `student` VALUES ('123456', '123456', '小明', '男', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '24214', '2414', '41', '4141', '1-105');
INSERT INTO `student` VALUES ('124124221', '1424141', '142414', '男', '', '', '', '', '', '');
INSERT INTO `student` VALUES ('222222', '1', '小华', '男', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '5', '1235', '315', '351', '1-304');
INSERT INTO `student` VALUES ('333333', '1', '小胖', '男', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '1515', '5', '515', '351', '1-105');
INSERT INTO `student` VALUES ('444444', '1', '小润', '男', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '235', '32523', '525', '2352', '1-202');
INSERT INTO `student` VALUES ('555555', '1', '小红', '女', 'http://172.20.10.2:8181/dormitoryManage/upload/studentImg/1581073941346_timg-1.jpg', '3', '5', '435243', '624', '3-101');

-- ----------------------------
-- Table structure for `visitor`
-- ----------------------------
DROP TABLE IF EXISTS `visitor`;
CREATE TABLE `visitor` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '访客登记id号',
  `dormitoryid` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿舍id号',
  `name` varchar(20) NOT NULL COMMENT '访客姓名',
  `identity` varchar(20) NOT NULL COMMENT '访客与宿舍人员关系',
  `remark` varchar(200) DEFAULT NULL COMMENT '做什么事',
  `isagree` varchar(20) NOT NULL COMMENT '是否同意',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '到访时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of visitor
-- ----------------------------
INSERT INTO `visitor` VALUES ('1', '1-101', '3123', '1231', '133', '是', '2020年02月07日 05:41:02');
INSERT INTO `visitor` VALUES ('2', '1-101', '3131', '3131', '3131', '是', '2020年02月07日 06:01:35');
INSERT INTO `visitor` VALUES ('3', '1-101', '31313', '1313', '', '否', '2020年02月07日 06:27:05');

-- ----------------------------
-- Table structure for `water`
-- ----------------------------
DROP TABLE IF EXISTS `water`;
CREATE TABLE `water` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT '送水id号',
  `dormitoryid` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '宿舍id号',
  `num` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '送水的数量',
  `time` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '送水时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of water
-- ----------------------------
INSERT INTO `water` VALUES ('1', '1-101', '2122', '2020年02月07日 05:05:52');
INSERT INTO `water` VALUES ('2', '1-101', '1231', '2020年02月07日 05:20:28');
INSERT INTO `water` VALUES ('3', '1-101', '131', '2020年02月07日 06:26:53');
INSERT INTO `water` VALUES ('4', '1-101', '977', '2020年02月07日 10:54:13');
